﻿@echo off
chcp 65001 >nul
title EFD 眼睛特徵提取與即時疲勞監控研究系統
cd /d "%~dp0"

echo ==================================================================
echo   EFD 眼睛特徵提取與即時疲勞監控研究系統 (Windows 桌面端)
echo ==================================================================
echo 正在啟動系統，請稍候...

if not exist "EFD.exe" (
    echo [錯誤] 找不到 EFD.exe，請確認檔案未被解壓縮軟體分離。
    pause
    exit /b 1
)

echo 正在啟動 EFD 即時視覺與疲勞監控核心...
echo 關閉介面後本視窗將自動最小化至工作列，並在背景持續輸出最新眼動數據。
echo.
"%~dp0EFD.exe"
if %ERRORLEVEL% neq 0 (
    pause
)
