﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Creating desktop shortcut for EFD...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'EFD Fatigue Detection.lnk')); $s.TargetPath = '%~dp0EFD.exe'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'EFD Eye Fatigue Detection System'; if (Test-Path '%~dp0assets\app.ico') { $s.IconLocation = '%~dp0assets\app.ico'; } else { $s.IconLocation = '%~dp0EFD.exe,0'; }; $s.Save();"
if %ERRORLEVEL% equ 0 ( echo [Success] Desktop shortcut created successfully! ) else ( echo [Notice] Direct shortcut creation skipped. )
timeout /t 3 >nul
exit
