﻿@echo off
chcp 65001 >nul
title EFD Eye Fatigue Detection System
cd /d "%~dp0"

echo ==================================================================
echo   EFD Eye Fatigue Detection System (v2.0.0)
echo ==================================================================
echo Launching application...

if not exist "EFD.exe" (
    echo [Error] EFD.exe not found in current directory.
    pause
    exit /b 1
)

start "" "%~dp0EFD.exe"
exit
