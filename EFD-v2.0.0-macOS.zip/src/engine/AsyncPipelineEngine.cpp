#include "AsyncPipelineEngine.hpp"
#include <chrono>
#include <algorithm>
#include <iostream>

namespace efd {

AsyncPipelineEngine::AsyncPipelineEngine(PlatformType platform)
    : m_lifecycle(platform),
      m_syncWorker(m_database),
      m_camera(std::make_unique<CameraService>(640, 480, 30.0f)),
      m_landmarker(std::make_unique<FaceLandmarker>()),
      m_extractor(300, 0.21f),
      m_baseline(0.31f, 0.7f, 1.5f, 300),
      m_emdCalculator(4, 15, 0.05f),
      m_mseCalculator(5, 2, 0.15f),
      m_stateMachine(1200, 300, 300) {
    m_landmarker->initialize();
    m_database.initialize();
    m_studyTracker.initialize();
    m_syncWorker.setEndpointUrl(m_studyTracker.getCloudSyncEndpoint());
    m_cachedComplexity.complexityIndex = 4.5f;
    m_cachedComplexity.imfCount = 2;

    // 綁定生命週期事件監聽
    m_lifecycle.setLifecycleCallback([this](const LifecycleEvent& event) {
        this->handleLifecycleEvent(event);
    });
}

AsyncPipelineEngine::~AsyncPipelineEngine() {
    stop();
}

bool AsyncPipelineEngine::start() {
    if (m_isRunning.load()) {
        return true;
    }

    m_isRunning.store(true);
    m_isPaused.store(false);
    m_processedFrameCount.store(0);

    // 啟動 Thread 2: 視覺推論執行緒
    m_inferenceThread = std::thread(&AsyncPipelineEngine::inferenceWorkerLoop, this);

    // 啟動 Thread 3: 訊號與狀態分析執行緒
    m_signalProcessingThread = std::thread(&AsyncPipelineEngine::signalProcessingWorkerLoop, this);

    // 註冊相機影格回呼並啟動 Thread 1: 相機擷取
    m_camera->setFrameCallback([this](const RawFrame& frame) {
        if (!this->m_isPaused.load()) {
            std::lock_guard<std::mutex> lock(this->m_frameQueueMutex);
            while (this->m_frameQueue.size() >= MAX_FRAME_QUEUE) {
                this->m_frameQueue.pop(); // 丟棄過期影格保證即時性
            }
            this->m_frameQueue.push(frame);
            this->m_frameQueueCv.notify_one();
        }
    });
    m_camera->start();

    return true;
}

void AsyncPipelineEngine::pause() {
    if (m_isRunning.load() && !m_isPaused.load()) {
        m_isPaused.store(true);
        if (m_camera) {
            m_camera->stop();
        }
        m_lifecycle.transitionTo(AppLifecycleState::Suspended, "Engine paused by system/user");
    }
}

void AsyncPipelineEngine::resume() {
    if (m_isRunning.load() && m_isPaused.load()) {
        m_isPaused.store(false);
        if (m_camera) {
            m_camera->start();
        }
        m_lifecycle.transitionTo(AppLifecycleState::Resumed, "Engine resumed (Hot-Resume)");
    }
}

void AsyncPipelineEngine::stop() {
    if (m_isRunning.load()) {
        m_isRunning.store(false);
        m_isPaused.store(false);

        m_frameQueueCv.notify_all();
        m_inferenceQueueCv.notify_all();

        if (m_camera) {
            m_camera->stop();
        }

        if (m_inferenceThread.joinable()) {
            m_inferenceThread.join();
        }

        if (m_signalProcessingThread.joinable()) {
            m_signalProcessingThread.join();
        }

        // 清空佇列
        {
            std::lock_guard<std::mutex> lock(m_frameQueueMutex);
            while (!m_frameQueue.empty()) m_frameQueue.pop();
        }
        {
            std::lock_guard<std::mutex> lock(m_inferenceQueueMutex);
            while (!m_inferenceQueue.empty()) m_inferenceQueue.pop();
        }

        m_database.flush();
        m_lifecycle.transitionTo(AppLifecycleState::Terminating, "Engine terminated");
    }
}

bool AsyncPipelineEngine::isRunning() const {
    return m_isRunning.load();
}

bool AsyncPipelineEngine::isPaused() const {
    return m_isPaused.load();
}

void AsyncPipelineEngine::setTelemetryCallback(TelemetryCallback callback) {
    m_telemetryCallback = std::move(callback);
}

void AsyncPipelineEngine::setAlertCallback(AlertCallback callback) {
    m_stateMachine.setAlertCallback(std::move(callback));
}

void AsyncPipelineEngine::calibrate(float durationSeconds) {
    std::vector<float> sampleList = m_extractor.getEarHistory();
    int samples = static_cast<int>(durationSeconds * 30.0f);
    if (sampleList.size() > static_cast<size_t>(samples)) {
        sampleList.erase(sampleList.begin(), sampleList.begin() + (sampleList.size() - samples));
    }
    if (sampleList.empty()) {
        sampleList.assign(samples > 0 ? samples : 30, 0.31f);
    }
    m_baseline.calibrate(sampleList);
    m_extractor.setEyeClosedThreshold(m_baseline.getCurrentThreshold());
}

void AsyncPipelineEngine::setSimulatedEyeOpenness(float openness) {
    if (m_landmarker) {
        m_landmarker->setSimulatedEyeOpenness(openness);
    }
}

bool AsyncPipelineEngine::triggerManualDataSync() {
    m_database.flush();
    return m_syncWorker.triggerDailySync(
        m_studyTracker.getSubjectUuid(),
        m_studyTracker.getCurrentDay(),
        nullptr
    );
}

bool AsyncPipelineEngine::checkAndTriggerNightlySync() {
    auto nowTime = std::chrono::system_clock::now();
    std::time_t nowT = std::chrono::system_clock::to_time_t(nowTime);
    std::tm tmNow{};
#ifdef _WIN32
    localtime_s(&tmNow, &nowT);
#else
    localtime_r(&nowT, &tmNow);
#endif
    if (tmNow.tm_hour < 21) {
        return false;
    }

    int todayDateInt = (tmNow.tm_year + 1900) * 10000 + (tmNow.tm_mon + 1) * 100 + tmNow.tm_mday;
    if (m_studyTracker.getLastSyncedDate() == todayDateInt) {
        return false; // 今日已完成同步，防止任何重複觸發
    }

    // 原子化持久記錄已同步日期至設定檔
    m_studyTracker.setLastSyncedDate(todayDateInt);
    m_lastSyncedDateInt = todayDateInt;
    std::cout << "[夜間科研同步] 21:00 定時觸發：落盤並同步當日眼動數據 (實驗第 " 
              << m_studyTracker.getCurrentDay() << " 天)...\n";
    m_database.flush();
    return m_syncWorker.triggerDailySync(
        m_studyTracker.getSubjectUuid(),
        m_studyTracker.getCurrentDay(),
        nullptr
    );
}

void AsyncPipelineEngine::handleLifecycleEvent(const LifecycleEvent& event) {
    if (event.currentState == AppLifecycleState::Resumed) {
        // 改良點 3: 熱重啟快速基準再校準 (1 秒內快速重同步光線與姿勢)
        std::vector<float> resumeSamples = m_extractor.getEarHistory();
        if (resumeSamples.size() > 30) {
            resumeSamples.erase(resumeSamples.begin(), resumeSamples.begin() + (resumeSamples.size() - 30));
        }
        if (resumeSamples.empty()) {
            resumeSamples.assign(30, 0.31f);
        }
        m_baseline.fastRecalibrate(resumeSamples);
        m_extractor.setEyeClosedThreshold(m_baseline.getCurrentThreshold());

        // 若在背景或休眠超過 5 分鐘，自動向狀態機發送離座清零
        if (event.elapsedBackgroundSeconds >= 300) {
            m_stateMachine.update(false, 0.0f, 0.0f, 0.0f, static_cast<float>(event.elapsedBackgroundSeconds));
        }
    }
}

// -----------------------------------------------------------------------------
// Thread 2: 視覺特徵推論迴圈 (Inference Worker Loop)
// -----------------------------------------------------------------------------
void AsyncPipelineEngine::inferenceWorkerLoop() {
    while (m_isRunning.load()) {
        RawFrame frame;
        {
            std::unique_lock<std::mutex> lock(m_frameQueueMutex);
            m_frameQueueCv.wait(lock, [this]() {
                return !m_frameQueue.empty() || !m_isRunning.load();
            });

            if (!m_isRunning.load()) break;

            frame = std::move(m_frameQueue.front());
            m_frameQueue.pop();
        }

        // 執行 468 點特徵定位推論
        LandmarkDetectionResult detection = m_landmarker->detect(frame);

        // 將結果遞交至 Thread 3 佇列
        {
            std::lock_guard<std::mutex> lock(m_inferenceQueueMutex);
            while (m_inferenceQueue.size() >= MAX_INFERENCE_QUEUE) {
                m_inferenceQueue.pop();
            }
            m_inferenceQueue.push(InferencePackage{std::move(frame), std::move(detection), m_landmarker->getLatestPresenceDiagnostic()});
            m_inferenceQueueCv.notify_one();
        }
    }
}

// -----------------------------------------------------------------------------
// Thread 3: 訊號分析與狀態機推進迴圈 (Signal & State Processing Worker Loop)
// -----------------------------------------------------------------------------
void AsyncPipelineEngine::signalProcessingWorkerLoop() {
    // [修正 B] 記錄上一幀處理時刻，確保 deltaSec 是真實時間間隔
    auto lastFrameTime = std::chrono::steady_clock::now();

    while (m_isRunning.load()) {
        InferencePackage package;
        {
            std::unique_lock<std::mutex> lock(m_inferenceQueueMutex);
            m_inferenceQueueCv.wait(lock, [this]() {
                return !m_inferenceQueue.empty() || !m_isRunning.load();
            });

            if (!m_isRunning.load()) break;

            package = std::move(m_inferenceQueue.front());
            m_inferenceQueue.pop();
        }

        // 1. 計算幾何特徵 (EAR / PERCLOS / 眨眼率) - 僅在偵測到正對鏡頭人臉時計算
        EyeMetrics eyeMetrics;
        if (package.detection.hasFace) {
            eyeMetrics = m_extractor.processFrame(package.detection.landmarks, m_camera->getFps());
        } else {
            // 人臉未偵測到或離座：幾何指標全部歸零，杜絕假疲勞數據
            eyeMetrics.earAvg = 0.0f;
            eyeMetrics.earLeft = 0.0f;
            eyeMetrics.earRight = 0.0f;
            eyeMetrics.isEyeClosed = false;
            eyeMetrics.perclos = 0.0f;
            eyeMetrics.blinkRatePerMin = 0.0f;
        }

        // 2. 動態滑動窗口基準自適應更新 (未偵測到人臉時不污染基準)
        float currentThreshold = package.detection.hasFace
            ? m_baseline.update(eyeMetrics.earAvg, eyeMetrics.isEyeClosed)
            : m_baseline.getCurrentThreshold();
        m_extractor.setEyeClosedThreshold(currentThreshold);

        // 3. 非線性複雜度分析 (EMD / MSE / CI)
        int64_t count = ++m_processedFrameCount;
        if (package.detection.hasFace) {
            if (count >= 30 && count % 15 == 0) {
                std::vector<float> earHistory = m_extractor.getEarHistory();
                m_cachedComplexity = m_mseCalculator.calculateComplexity(earHistory);
            } else if (count < 30) {
                // 冷啟動前 30 幀給予平滑清醒先驗值，避免 CI=0 造成疲勞分數突波跳變
                m_cachedComplexity.complexityIndex = 4.5f;
                m_cachedComplexity.imfCount = 2;
            }
        } else {
            m_cachedComplexity.complexityIndex = 0.0f;
        }

        // 4. 20/5/5 防打擾狀態機推進 (傳入即時人臉在場與正視狀態)
        // [修正 B] 計算真實時間增量（而非固定 1/FPS 估算值）
        auto nowFrameTime = std::chrono::steady_clock::now();
        float deltaSec = std::chrono::duration<float>(nowFrameTime - lastFrameTime).count();
        // 防止初始化或長時間暫停後的時間跳躍（限制在合理範圍 0.001s ~ 0.5s）
        deltaSec = std::clamp(deltaSec, 0.001f, 0.5f);
        lastFrameTime = nowFrameTime;
        SystemState state = m_stateMachine.update(
            package.detection.hasFace,
            eyeMetrics.perclos,
            eyeMetrics.blinkRatePerMin,
            m_cachedComplexity.complexityIndex,
            deltaSec
        );

        // 5. 定期落盤至本地結構化資料庫 (每 1 秒 30 幀記錄一筆，僅在人臉在座時記錄有效特徵)
        if (count % 30 == 0 && package.detection.hasFace) {
            FatigueRecord record;
            record.timestampMs = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            record.subjectUuid = m_studyTracker.getSubjectUuid();
            record.ear = eyeMetrics.earAvg;
            record.perclos = eyeMetrics.perclos;
            record.complexityIndex = m_cachedComplexity.complexityIndex;
            record.fatigueScore = state.currentFatigueScore;
            record.alertLevel = state.fatigueLevel;
            m_database.logRecord(record);
        }

        // 5.1 夜間定時自動儲存與上傳 (每 900 幀 / 約 30 秒委派原子檢查，持久化防重複)
        if (count % 900 == 0) {
            checkAndTriggerNightlySync();
        }

        // 6. 分發遙測至 UI Thread
        if (m_telemetryCallback) {
            EngineTelemetry telemetry;
            telemetry.latestFrame = std::move(package.frame);
            telemetry.detection = std::move(package.detection);
            telemetry.presenceDiagnostic = std::move(package.presenceDiagnostic);
            telemetry.eyeMetrics = eyeMetrics;
            telemetry.complexityMetrics = m_cachedComplexity;
            telemetry.systemState = state;
            telemetry.currentThreshold = currentThreshold;
            telemetry.totalFramesProcessed = count;
            telemetry.lifecycleSummary = m_lifecycle.getStatusSummary();
            telemetry.currentStudyDay = m_studyTracker.getCurrentDay();
            telemetry.studyStatus = m_studyTracker.getStatus();
            telemetry.subjectUuid = m_studyTracker.getSubjectUuid();

            std::string driverName = m_camera->getActiveDriverName();
            bool isSynthetic = m_camera->isUsingSyntheticFallback();
            std::string statusLabel = isSynthetic ? "模擬測試相機 (Synthetic)" : driverName;
            telemetry.lifecycleSummary = "相機狀態: " + statusLabel + " | 30 FPS 串流正常 (累計 " + std::to_string(count) + " 幀)";

            m_telemetryCallback(telemetry);
        }
    }
}

} // namespace efd

