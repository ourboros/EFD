#include <iostream>
#include "NativeWelcomeWindow.hpp"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include "NativeWelcomeWindow.hpp"
#elif defined(__APPLE__)
#include "macos/MacWelcomeWindow.h"
#endif

int main(int argc, char* argv[]) {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    int winWidth = 960;
    int winHeight = 640;
    bool isMobileMode = false;
    bool isBackgroundMode = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--mobile" || arg == "-m" || arg == "--phone") {
            winWidth = 390;
            winHeight = 844; // iPhone 14 / 標準直立手機視窗解析度
            isMobileMode = true;
        } else if (arg == "--tablet" || arg == "-t") {
            winWidth = 768;
            winHeight = 1024;
        } else if (arg == "--background" || arg == "-b" || arg == "--autostart" || arg == "--silent") {
            isBackgroundMode = true;
        }
    }

#ifdef _WIN32
    // 單一實例檢測 (Single-Instance Detection via Named Mutex)
    HANDLE hMutex = CreateMutexW(NULL, FALSE, L"Global\\EFD_FatigueMonitor_SingleInstance_Mutex");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        // 背景程序已在執行中，只開啟/喚醒現有操作介面
        HWND existingHwnd = FindWindowW(L"EFD_FullNativeWindow", NULL);
        if (existingHwnd) {
            std::cout << "[系統提示] 偵測到 EFD 核心監控程序已在背景常駐執行中。\n";
            std::cout << "[系統提示] 正在喚醒現有程序操作介面，不重複啟動攝影機硬體...\n";
            PostMessageW(existingHwnd, WM_USER + 201, 0, 0);
            ShowWindow(existingHwnd, SW_RESTORE);
            SetForegroundWindow(existingHwnd);
        } else {
            std::cout << "[系統提示] 偵測到 EFD 核心監控程序已在背景執行中。\n";
        }
        if (hMutex) CloseHandle(hMutex);
        return 0; // 新進程自動退出，避免多重實例搶佔攝影機
    }
#endif

    std::cout << "====================================================\n";
    std::cout << "  EFD 七階段視覺校準、疲勞監控與科研後測系統\n";
    std::cout << "  EFD 視覺校準、疲勞監控與科研後測系統\n";
    if (isMobileMode) {
        std::cout << "  [模式] 智慧型手機模擬器 (390 x 844 直立視窗)\n";
    } else {
        std::cout << "  [模式] 桌面寬螢幕模式 (960 x 640 橫向視窗)\n";
    }
    std::cout << "  - 階段一: 歡迎介面 (Logo + 感謝協助測試EFD)\n";
    std::cout << "  - 階段二: 特徵提取說明 (DEMO 演示預覽 + 相機狀態)\n";
    std::cout << "  - 階段三: 3 秒倒數計時等待 (3 -> 2 -> 1)\n";
    std::cout << "  - 階段四: 多點動態眼動特徵提取 (動態黃點採樣)\n";
    std::cout << "  - 階段五: 即時眼睛疲勞監控中心 (動態數據跳動)\n";
    std::cout << "  - 階段六: 施測結束門禁 (資產 5: 後測問卷引導)\n";
    std::cout << "  - 階段七: 問卷提交完成 (資產 6: 解鎖授權與解除安裝)\n";
    std::cout << "  - 階段五: 基準校準完成結果提示\n";
    std::cout << "  - 階段六: 即時眼睛疲勞監控中心 (動態數據跳動)\n";
    std::cout << "  - 階段七: 系統設定介面\n";
    std::cout << "  - 階段八: 施測結束後測介面 (後測問卷引導)\n";
    std::cout << "  - 階段九: 問卷提交完成 (科研憑證與解除鎖定)\n";
    std::cout << "====================================================\n";

#ifdef _WIN32
    efd::NativeWelcomeWindow window(winWidth, winHeight, isBackgroundMode);
    return window.run();
#elif defined(__APPLE__)
    efd::MacWelcomeWindow window(winWidth, winHeight);
    return window.run();
#else
    std::cerr << "Unsupported platform for native GUI.\n";
    return 1;
#endif
}

